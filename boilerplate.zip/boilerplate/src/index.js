require("dotenv").config();
const httpServer = require("./app.js");
const db = require("./db/models/index.js");

const startServer = async () => {
  try {
    await db.sequelize.authenticate();
    console.log("Connected to MySQL");
    httpServer.listen(process.env.PORT || 8080, () => {
      console.log("⚙️  Server is running on port: " + process.env.PORT);
    });
  } catch (error) {
    console.error("Unable to connect to the database:", error);
  }
};

startServer();
