const express = require("express");
const { createServer } = require("http");
const helmet = require('helmet');
const morganMiddleware =require('./logger/morgan.logger');

const app = express();

const httpServer = createServer(app);

// set security HTTP headers
app.use(helmet());

app.use(morganMiddleware);
// api routes
const errorHandler = require('./middlewares/error.middlewares');
const healthcheckRouter = require('./routes/healthcheck.routes');


// * healthcheck
app.use("/api/v1/healthcheck", healthcheckRouter);


// common error handling middleware
app.use(errorHandler);
module.exports = httpServer;
