

/**
 * @param {import("express").Request} req
 * @description **This utility function is responsible for removing unused image files due to the api fail**.
 *
 * **For example:**
 * * This can occur when product is created.
 * * In product creation process the images are getting uploaded before product gets created.
 * * Once images are uploaded and if there is an error creating a product, the uploaded images are unused.
 * * In such case, this function will remove those unused images.
 */
module.exports = removeUnusedMulterImageFilesOnError = (req) => {
    try {
      const multerFile = req.file;
      const multerFiles = req.files;
  
      if (multerFile) {
        // If there is file uploaded and there is validation error
        // We want to remove that file
        removeLocalFile(multerFile.path);
      }
  
      if (multerFiles) {
        /** @type {Express.Multer.File[][]}  */
        const filesValueArray = Object.values(multerFiles);
        // If there are multiple files uploaded for more than one fields
        // We want to remove those files as well
        filesValueArray.map((fileFields) => {
          fileFields.map((fileObject) => {
            removeLocalFile(fileObject.path);
          });
        });
      }
    } catch (error) {
      // fail silently
      console.log("Error while removing image files: ", error);
    }
};